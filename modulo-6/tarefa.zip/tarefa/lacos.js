let i = 0;

for (i = 0; i <5; i++) {
    console.log(`Resultado =  ${i}`); 
}

// while (i < 5) {
//     console.log(`Resultado = ${i}`);
//     i++;
// }

// do {
//     console.log(`Resultado = ${i}`);
//     i++;
// } while (i < 5);     