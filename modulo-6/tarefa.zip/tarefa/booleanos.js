let verdadeiro = true;
let falso = false;

console.log(verdadeiro);
console.log(falso);

let a = 6;
let b = 13;

console.log(a==b);
console.log(a!=b);
console.log(a <= b);
console.log(a >= b);

let num = 7;
let str = "7";

console.log(num==str);
console.log(num === str);
console.log(num !== str);